<?php
// Modificado por Alex Escamilla

    require_once "../config/connection.php";

    $id = intval($_GET["id"] ?? 0);

    // Aquí va el código para obtener el libro usando una consulta preparada
    if ($id > 0) {
        $stmt = $conn->prepare("SELECT id, titulo, isbn, anio_publicacion, editorial, cantidad, disponibles, id_categoria FROM vacantes WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $resultado = $stmt->get_result();
        $libro = $resultado->fetch_assoc();
        $stmt->close();
    } else {
        header("Location: index.php?error=" . urlencode("ID inválido"));
        exit;
    }
    // Aquí va el código para obtener los candidatos asignados al libro usando una consulta preparada
    $stmt = $conn->prepare("SELECT candidatos.id, candidatos.nombre, candidatos.apellido FROM candidatos INNER JOIN libro_autor ON candidatos.id = libro_autor.id_autor WHERE libro_autor.id_libro = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $resultado = $stmt->get_result();
    $candidatos_asignados = [];
    while($autor = $resultado->fetch_assoc()){
        $candidatos_asignados[] = $autor;
    }
    $stmt->close();

    // Aquí va el código para obtener todas las categorías usando una consulta preparada
    $stmt = $conn->prepare("SELECT id, nombre FROM areas ORDER BY nombre");
    $stmt->execute();
    $resultado = $stmt->get_result();
    $areas = [];
    while($categoria = $resultado->fetch_assoc()){
        $areas[] = $categoria;
    }
    $stmt->close();

    // Aquí va el código para obtener todos los candidatos usando una consulta preparada
    $stmt = $conn->prepare("SELECT id, nombre, apellido FROM candidatos ORDER BY nombre, apellido");
    $stmt->execute();
    $resultado = $stmt->get_result();
    $candidatos = [];
    while($autor = $resultado->fetch_assoc()){
        $candidatos[] = $autor;
    }
    $stmt->close();

?>
<?php include_once "../includes/header.php"; ?>

<div class="page-header">
    <h1><i class="fas fa-book-open"></i> Editar Libro</h1>
    <a href="index.php" class="btn btn-secondary">
        <i class="fas fa-arrow-left"></i> Volver
    </a>
</div>

<div class="card">
    <form action="update.php" method="POST">
        <input type="hidden" name="id" value="<?= $libro["id"] ?? $id ?>">

        <div class="form-group">
            <label><i class="fas fa-book"></i> Título</label>
            <input type="text" name="titulo" value="<?= htmlspecialchars($libro["titulo"] ?? "") ?>" required>
        </div>

        <div class="form-group">
            <label><i class="fas fa-barcode"></i> ISBN</label>
            <input type="text" name="isbn" value="<?= htmlspecialchars($libro["isbn"] ?? "") ?>">
        </div>

        <div class="form-group">
            <label><i class="fas fa-calendar"></i> Año de Publicación</label>
            <input type="number" name="anio_publicacion" value="<?= $libro["anio_publicacion"] ?? "" ?>" min="1000" max="<?= date('Y') ?>">
        </div>

        <div class="form-group">
            <label><i class="fas fa-building"></i> Editorial</label>
            <input type="text" name="editorial" value="<?= htmlspecialchars($libro["editorial"] ?? "") ?>">
        </div>

        <div class="form-group">
            <label><i class="fas fa-cubes"></i> Cantidad</label>
            <input type="number" name="cantidad" value="<?= $libro["cantidad"] ?? 0 ?>" min="0">
        </div>

        <div class="form-group">
            <label><i class="fas fa-check-circle"></i> Disponibles</label>
            <input type="number" name="disponibles" value="<?= $libro["disponibles"] ?? 0 ?>" min="0">
        </div>

        <div class="form-group">
            <label><i class="fas fa-tag"></i> Categoría</label>
            <select name="id_categoria" required>
                <option value="">-- Selecciona una categoría --</option>
                <?php
                    // Aquí va el código para mostrar las categorías en el <select>
                    $stmt = $conn->prepare("SELECT id, nombre FROM areas ORDER BY nombre");
                    $stmt->execute();
                    $resultado = $stmt->get_result();
                    while($categoria = $resultado->fetch_assoc()){
                        echo "<option value='" . $categoria["id"] . "'>" . htmlspecialchars($categoria["nombre"]) . "</option>";
                    }
                ?>
            </select>
        </div>

        <div class="form-group">
            <label><i class="fas fa-user"></i> Autor(es)</label>
            <select name="id_candidatos[]" multiple required>
                <?php
                    // Aquí va el código para mostrar los candidatos en el <select>
                    $stmt = $conn->prepare("SELECT vacantes.id, vacantes.titulo, candidatos.nombre, candidatos.apellido FROM vacantes INNER JOIN libro_autor ON vacantes.id = libro_autor.id_libro INNER JOIN candidatos ON libro_autor.id_autor = candidatos.id ORDER BY nombre, apellido");
                    $stmt->execute();
                    $resultado = $stmt->get_result();
                    while($autor = $resultado->fetch_assoc()){
                        echo "<option value='" . $autor["id"] . "'>" . htmlspecialchars($autor["nombre"]) . " " . htmlspecialchars($autor["apellido"]) . "</option>";
                    }
                ?>
            </select>
            <small>Mantén Ctrl (o Cmd) para seleccionar varios candidatos</small>
        </div>

        <div class="form-actions">
            <button type="submit" class="btn btn-success">
                <i class="fas fa-save"></i> Actualizar
            </button>
            <a href="index.php" class="btn btn-secondary">
                <i class="fas fa-times"></i> Cancelar
            </a>
        </div>
    </form>
</div>

<?php include_once "../includes/footer.php"; ?>
