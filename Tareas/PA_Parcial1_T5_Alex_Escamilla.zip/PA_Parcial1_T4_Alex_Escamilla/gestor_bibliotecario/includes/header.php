<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema Bibliotecario Alex</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<aside class="sidebar">
    <div class="sidebar-header">
        <h2><i class="fas fa-book-open"></i> Bibliotech</h2>
        <p>Sistema de Gestión</p>
    </div>
    <?php
// Modificado por Alex Escamilla
 $ruta = $_SERVER['PHP_SELF']; ?>
    <nav class="sidebar-nav">
        <a href="../dashboard.php" <?= strpos($ruta, 'dashboard') !== false ? 'class="active"' : '' ?>><i class="fas fa-home"></i> Dashboard</a>
        <a href="../areas/index.php" <?= strpos($ruta, 'areas') !== false ? 'class="active"' : '' ?>><i class="fas fa-tags"></i> Categorías</a>
        <a href="../candidatos/index.php" <?= strpos($ruta, 'candidatos') !== false ? 'class="active"' : '' ?>><i class="fas fa-user"></i> Candidatos</a>
        <a href="../vacantes/index.php" <?= strpos($ruta, 'vacantes') !== false ? 'class="active"' : '' ?>><i class="fas fa-book"></i> Vacantes</a>
        <a href="../usuarios/index.php" <?= strpos($ruta, 'usuarios') !== false ? 'class="active"' : '' ?>><i class="fas fa-users"></i> Usuarios</a>
        <a href="../postulaciones/index.php" <?= strpos($ruta, 'postulaciones') !== false ? 'class="active"' : '' ?>><i class="fas fa-hand-holding-heart"></i> Préstamos</a>
    </nav>
</aside>

<div class="main-content">
