<?php

// 1. Potencia

function potencia($b, $e){
    if($e == 0){
        return 1;
    }

    return $b * potencia($b, $e - 1);
}

echo potencia(2,3);



// 2. Multiplicar usando sumas

function multiplicar($a, $b){
    if($b == 0){
        return 0;
    }

    return $a + multiplicar($a, $b - 1);
}

echo multiplicar(3,4);



// 3. Contar caracteres

function contar($txt){
    if($txt == ""){
        return 0;
    }

    return 1 + contar(substr($txt,1));
}

echo contar("hola");



// 4. Palindromo

function palindromo($txt){

    if(strlen($txt) <= 1){
        return true;
    }

    if($txt[0] != $txt[strlen($txt)-1]){
        return false;
    }

    return palindromo(substr($txt,1,-1));
}

echo palindromo("oso");



// 5. MCD

function mcd($a,$b){

    if($b == 0){
        return $a;
    }

    return mcd($b, $a % $b);
}

echo mcd(24,18);



// 6. Decimal a binario

function binario($n){

    if($n < 2){
        return $n;
    }

    return binario(intdiv($n,2)) . ($n % 2);
}

echo binario(10);



// 7. Sumar arreglo

function suma($arr, $i = 0){

    if($i == count($arr)){
        return 0;
    }

    return $arr[$i] + suma($arr, $i + 1);
}

echo suma([1,2,3]);



// 8. Buscar elemento

function buscar($arr, $x, $i = 0){

    if($i == count($arr)){
        return false;
    }

    if($arr[$i] == $x){
        return true;
    }

    return buscar($arr, $x, $i + 1);
}

echo buscar([1,2,3],2);



// 9. Contar vocales

function vocales($txt){

    if($txt == ""){
        return 0;
    }

    $l = strtolower($txt[0]);

    if($l=="a" || $l=="e" || $l=="i" || $l=="o" || $l=="u"){
        return 1 + vocales(substr($txt,1));
    }

    return vocales(substr($txt,1));
}

echo vocales("hola");



// 10. Suma pares

function pares($n){

    if($n <= 0){
        return 0;
    }

    if($n % 2 != 0){
        return pares($n - 1);
    }

    return $n + pares($n - 2);
}

echo pares(10);

?>